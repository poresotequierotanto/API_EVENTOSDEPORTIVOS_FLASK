from setuptools import setup

setup(
    name='appProyecto',
    packages=['appProyecto'],
    include_package_data=True,
    install_requires=['flask']
)